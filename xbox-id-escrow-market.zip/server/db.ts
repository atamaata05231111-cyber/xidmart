import { and, desc, eq, gt, isNull, like, or, sql, type SQL } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { nanoid } from "nanoid";
import {
  adminInviteCodes,
  auditLogs,
  credentialVault,
  listings,
  transactionEvents,
  transactionMessages,
  transactions,
  userProfiles,
  users,
  type InsertUser,
} from "../drizzle/schema";
import { ENV } from "./_core/env";
import { storagePut } from "./storage";
import { decryptCredential, encryptCredential, escapeFileName, hashAdminCode } from "./security";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

async function requireDb() {
  const db = await getDb();
  if (!db) throw new Error("データベースに接続できません。時間をおいて再度お試しください。");
  return db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId, lastSignedIn: user.lastSignedIn ?? new Date() };
  const updateSet: Record<string, unknown> = { lastSignedIn: values.lastSignedIn };
  for (const field of ["name", "email", "loginMethod"] as const) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

async function ensureProfile(user: { id: number; name: string | null; email: string | null }) {
  const db = await requireDb();
  const existing = await db.select().from(userProfiles).where(eq(userProfiles.userId, user.id)).limit(1);
  if (existing[0]) return existing[0];
  const defaultHandle = (user.name || user.email?.split("@")[0] || `member-${user.id}`).slice(0, 32);
  await db.insert(userProfiles).values({ userId: user.id, handle: defaultHandle });
  const created = await db.select().from(userProfiles).where(eq(userProfiles.userId, user.id)).limit(1);
  return created[0]!;
}

export async function getMyProfile(user: { id: number; name: string | null; email: string | null }) {
  return ensureProfile(user);
}

export async function saveMyProfile(user: { id: number; name: string | null; email: string | null }, input: { handle: string; bio?: string; isPublic: boolean }) {
  await ensureProfile(user);
  const db = await requireDb();
  await db.update(userProfiles).set({ handle: input.handle.trim(), bio: input.bio?.trim() || null, isPublic: input.isPublic }).where(eq(userProfiles.userId, user.id));
  return getMyProfile(user);
}

export async function uploadImage(userId: number, input: { fileName: string; mimeType: string; base64: string; area: "listing" | "payment" }) {
  const allowedTypes = ["image/jpeg", "image/png", "image/webp"];
  if (!allowedTypes.includes(input.mimeType)) throw new Error("JPEG、PNG、WebP形式の画像のみアップロードできます。");
  const bytes = Buffer.from(input.base64.replace(/^data:[^;]+;base64,/, ""), "base64");
  if (!bytes.length || bytes.length > 6 * 1024 * 1024) throw new Error("画像は6MB以下でアップロードしてください。");
  const key = `secure/${input.area}/${userId}/${nanoid(18)}-${escapeFileName(input.fileName)}`;
  const stored = await storagePut(key, bytes, input.mimeType);
  return { key: stored.key, url: stored.url };
}

export async function browseListings(input: { query?: string; category?: string; idLength?: number; characterType?: string }) {
  const db = await requireDb();
  const conditions: SQL[] = [eq(listings.state, "active"), eq(listings.verification, "approved")];
  if (input.category) conditions.push(eq(listings.category, input.category as typeof listings.category.enumValues[number]));
  if (input.query?.trim()) {
    const keyword = `%${input.query.trim().replace(/[\\%_]/g, "\\$&")}%`;
    conditions.push(like(listings.xboxId, keyword));
  }
  if (input.idLength) conditions.push(sql`CHAR_LENGTH(${listings.xboxId}) = ${input.idLength}`);
  if (input.characterType === "alphabet") conditions.push(sql`${listings.xboxId} REGEXP '^[A-Za-z]+$'`);
  if (input.characterType === "alphanumeric") conditions.push(sql`${listings.xboxId} REGEXP '^[A-Za-z][A-Za-z0-9]*$'`);
  if (input.characterType === "mixed") conditions.push(sql`${listings.xboxId} REGEXP '[0-9]'`);

  return db
    .select({
      id: listings.id,
      xboxId: listings.xboxId,
      category: listings.category,
      description: listings.description,
      priceYen: listings.priceYen,
      screenshotUrl: listings.screenshotUrl,
      createdAt: listings.createdAt,
      sellerHandle: userProfiles.handle,
    })
    .from(listings)
    .leftJoin(userProfiles, eq(userProfiles.userId, listings.sellerId))
    .where(and(...conditions))
    .orderBy(desc(listings.createdAt));
}

export async function getListing(id: string) {
  const db = await requireDb();
  const rows = await db
    .select({
      id: listings.id,
      sellerId: listings.sellerId,
      xboxId: listings.xboxId,
      category: listings.category,
      description: listings.description,
      priceYen: listings.priceYen,
      screenshotUrl: listings.screenshotUrl,
      verification: listings.verification,
      state: listings.state,
      createdAt: listings.createdAt,
      sellerHandle: userProfiles.handle,
      sellerSince: users.createdAt,
    })
    .from(listings)
    .innerJoin(users, eq(users.id, listings.sellerId))
    .leftJoin(userProfiles, eq(userProfiles.userId, listings.sellerId))
    .where(eq(listings.id, id))
    .limit(1);
  return rows[0];
}

export async function createListing(user: { id: number }, input: { xboxId: string; category: typeof listings.category.enumValues[number]; description: string; priceYen: number; screenshot: { fileName: string; mimeType: string; base64: string } }) {
  const db = await requireDb();
  const image = await uploadImage(user.id, { ...input.screenshot, area: "listing" });
  const id = nanoid(16);
  await db.insert(listings).values({
    id,
    sellerId: user.id,
    xboxId: input.xboxId.trim(),
    category: input.category,
    description: input.description.trim(),
    priceYen: input.priceYen,
    screenshotUrl: image.url,
    screenshotKey: image.key,
    verification: "pending",
    state: "active",
  });
  await createAudit(user.id, "listing_created", "listing", id, "所有確認待ちの出品を作成");
  return { id };
}

export async function getMyListings(userId: number) {
  const db = await requireDb();
  return db.select().from(listings).where(eq(listings.sellerId, userId)).orderBy(desc(listings.createdAt));
}

export async function getMyDeals(userId: number) {
  const db = await requireDb();
  return db
    .select({
      id: transactions.id,
      listingId: transactions.listingId,
      status: transactions.status,
      amountYen: transactions.amountYen,
      feeYen: transactions.feeYen,
      payoutYen: transactions.payoutYen,
      buyerId: transactions.buyerId,
      sellerId: transactions.sellerId,
      createdAt: transactions.createdAt,
      xboxId: listings.xboxId,
      category: listings.category,
      buyerName: users.name,
    })
    .from(transactions)
    .innerJoin(listings, eq(listings.id, transactions.listingId))
    .innerJoin(users, eq(users.id, transactions.buyerId))
    .where(or(eq(transactions.buyerId, userId), eq(transactions.sellerId, userId)))
    .orderBy(desc(transactions.updatedAt));
}

export async function createDeal(user: { id: number }, listingId: string) {
  const db = await requireDb();
  const listing = await db.select().from(listings).where(eq(listings.id, listingId)).limit(1);
  const item = listing[0];
  if (!item || item.state !== "active" || item.verification !== "approved") throw new Error("この出品は現在購入できません。");
  if (item.sellerId === user.id) throw new Error("自分の出品は購入できません。");
  const id = nanoid(16);
  const feeYen = Math.floor(item.priceYen * 0.1);
  try {
    await db.insert(transactions).values({ id, listingId: item.id, buyerId: user.id, sellerId: item.sellerId, amountYen: item.priceYen, feeYen, payoutYen: item.priceYen - feeYen });
  } catch {
    throw new Error("この出品はすでに取引を開始しています。");
  }
  await db.update(listings).set({ state: "reserved" }).where(eq(listings.id, item.id));
  await createEvent(id, user.id, "deal_started", "購入申込みを受け付けました。PayPay入金をお待ちしています。");
  await createAudit(user.id, "deal_started", "transaction", id, `出品 ${item.id}`);
  return { id };
}

function canAccessDeal(deal: { buyerId: number; sellerId: number }, viewer: { id: number; role?: string }) {
  return viewer.role === "admin" || viewer.role === "operator" || deal.buyerId === viewer.id || deal.sellerId === viewer.id;
}

export async function getDealDetail(viewer: { id: number; role?: string }, id: string) {
  const db = await requireDb();
  const rows = await db
    .select({
      id: transactions.id,
      listingId: transactions.listingId,
      buyerId: transactions.buyerId,
      sellerId: transactions.sellerId,
      amountYen: transactions.amountYen,
      feeYen: transactions.feeYen,
      payoutYen: transactions.payoutYen,
      status: transactions.status,
      paymentReference: transactions.paymentReference,
      paymentProofUrl: transactions.paymentProofUrl,
      createdAt: transactions.createdAt,
      paymentReviewedAt: transactions.paymentReviewedAt,
      deliveredAt: transactions.deliveredAt,
      completedAt: transactions.completedAt,
      xboxId: listings.xboxId,
      category: listings.category,
      sellerHandle: userProfiles.handle,
    })
    .from(transactions)
    .innerJoin(listings, eq(listings.id, transactions.listingId))
    .leftJoin(userProfiles, eq(userProfiles.userId, transactions.sellerId))
    .where(eq(transactions.id, id))
    .limit(1);
  const deal = rows[0];
  if (!deal) return undefined;
  if (!canAccessDeal(deal, viewer)) throw new Error("この取引を閲覧する権限がありません。");

  const messageCondition = viewer.role === "admin" || viewer.role === "operator" || deal.sellerId === viewer.id
    ? eq(transactionMessages.transactionId, id)
    : and(eq(transactionMessages.transactionId, id), eq(transactionMessages.visibility, "participants"));
  const messages = await db
    .select({ id: transactionMessages.id, senderId: transactionMessages.senderId, body: transactionMessages.body, visibility: transactionMessages.visibility, createdAt: transactionMessages.createdAt, senderName: users.name, senderRole: users.role })
    .from(transactionMessages)
    .innerJoin(users, eq(users.id, transactionMessages.senderId))
    .where(messageCondition)
    .orderBy(transactionMessages.createdAt);
  const events = await db.select().from(transactionEvents).where(eq(transactionEvents.transactionId, id)).orderBy(transactionEvents.createdAt);

  let deliveredCredentials: string | null = null;
  const buyerCanView = deal.buyerId === viewer.id && ["delivered", "acceptance_pending", "completed"].includes(deal.status);
  if (buyerCanView) {
    const vault = await db.select().from(credentialVault).where(eq(credentialVault.transactionId, id)).limit(1);
    if (vault[0]?.releasedAt) deliveredCredentials = decryptCredential(vault[0]);
  }
  return { ...deal, messages, events, deliveredCredentials };
}

export async function submitPaymentProof(user: { id: number }, input: { dealId: string; reference: string; screenshot: { fileName: string; mimeType: string; base64: string } }) {
  const db = await requireDb();
  const detail = await getDealDetail(user, input.dealId);
  if (!detail || detail.buyerId !== user.id || detail.status !== "payment_pending") throw new Error("この取引では入金報告を受け付けられません。");
  const image = await uploadImage(user.id, { ...input.screenshot, area: "payment" });
  await db.update(transactions).set({ status: "payment_review", paymentReference: input.reference.trim(), paymentProofUrl: image.url, paymentProofKey: image.key }).where(eq(transactions.id, input.dealId));
  await createEvent(input.dealId, user.id, "payment_submitted", "入金報告を受領しました。運営が確認します。");
}

export async function submitCredentials(user: { id: number }, input: { dealId: string; credentials: string }) {
  const db = await requireDb();
  const detail = await getDealDetail(user, input.dealId);
  if (!detail || detail.sellerId !== user.id || detail.status !== "credentials_requested") throw new Error("現在、アカウント情報の提出はできません。");
  const encrypted = encryptCredential(input.credentials.trim());
  await db.insert(credentialVault).values({ id: nanoid(16), transactionId: input.dealId, submittedBy: user.id, ...encrypted }).onDuplicateKeyUpdate({ set: { ...encrypted, submittedBy: user.id, submittedAt: new Date(), reviewedAt: null, releasedAt: null } });
  await db.update(transactions).set({ status: "credentials_submitted" }).where(eq(transactions.id, input.dealId));
  await createEvent(input.dealId, user.id, "credentials_submitted", "アカウント情報を運営専用の暗号化保管庫へ提出しました。");
  await createAudit(user.id, "credentials_submitted", "transaction", input.dealId, "暗号化済み認証情報を提出");
}

export async function sendDealMessage(user: { id: number; role: string }, input: { dealId: string; body: string; operatorOnly?: boolean }) {
  const db = await requireDb();
  const detail = await getDealDetail(user, input.dealId);
  if (!detail) throw new Error("取引が見つかりません。");
  const visibility = input.operatorOnly && ["admin", "operator"].includes(user.role) ? "operator_only" as const : "participants" as const;
  await db.insert(transactionMessages).values({ id: nanoid(16), transactionId: input.dealId, senderId: user.id, body: input.body.trim(), visibility });
}

export async function acceptDelivery(user: { id: number }, dealId: string) {
  const db = await requireDb();
  const detail = await getDealDetail(user, dealId);
  if (!detail || detail.buyerId !== user.id || detail.status !== "delivered") throw new Error("この取引は受領確認できません。");
  await db.update(transactions).set({ status: "acceptance_pending" }).where(eq(transactions.id, dealId));
  await createEvent(dealId, user.id, "buyer_accepted", "購入者が受領確認を行いました。運営による出品者への送金待ちです。");
}

export async function openDispute(user: { id: number; role: string }, dealId: string, reason: string) {
  const db = await requireDb();
  const detail = await getDealDetail(user, dealId);
  if (!detail || ["completed", "cancelled"].includes(detail.status)) throw new Error("この取引では申し立てを開始できません。");
  await db.update(transactions).set({ status: "disputed" }).where(eq(transactions.id, dealId));
  await db.insert(transactionMessages).values({ id: nanoid(16), transactionId: dealId, senderId: user.id, body: `【申し立て】${reason.trim()}`, visibility: "participants" });
  await createEvent(dealId, user.id, "dispute_opened", "申し立てを受け付けました。運営が確認します。");
}

export async function operatorVerifyListing(actor: { id: number }, listingId: string, approve: boolean, note?: string) {
  const db = await requireDb();
  const item = await db.select().from(listings).where(eq(listings.id, listingId)).limit(1);
  if (!item[0]) throw new Error("出品が見つかりません。");
  await db.update(listings).set({ verification: approve ? "approved" : "rejected", state: approve ? item[0].state : "rejected", verificationNote: note?.trim() || null }).where(eq(listings.id, listingId));
  await createAudit(actor.id, approve ? "listing_approved" : "listing_rejected", "listing", listingId, note?.trim() || null);
}

export async function operatorUpdateDeal(actor: { id: number }, input: { dealId: string; action: "payment_confirm" | "request_credentials" | "review_credentials" | "release_to_buyer" | "complete_payout" | "cancel"; note?: string }) {
  const db = await requireDb();
  const rows = await db.select().from(transactions).where(eq(transactions.id, input.dealId)).limit(1);
  const deal = rows[0];
  if (!deal) throw new Error("取引が見つかりません。");
  const transition = {
    payment_confirm: { from: ["payment_review"], to: "credentials_requested", event: "payment_confirmed", message: "PayPay入金を確認しました。出品者はアカウント情報を提出してください。" },
    request_credentials: { from: ["payment_review", "payment_pending"], to: "credentials_requested", event: "credentials_requested", message: "出品者にアカウント情報の提出を依頼しました。" },
    review_credentials: { from: ["credentials_submitted"], to: "delivery_ready", event: "credentials_reviewed", message: "運営がアカウント情報を確認しました。購入者への引渡し準備が完了しました。" },
    release_to_buyer: { from: ["delivery_ready"], to: "delivered", event: "credentials_released", message: "運営から購入者へアカウント情報を安全に引き渡しました。" },
    complete_payout: { from: ["acceptance_pending"], to: "completed", event: "payout_completed", message: "取引を完了しました。手数料10%を差し引いた金額を出品者へ送金してください。" },
    cancel: { from: ["payment_pending", "payment_review", "credentials_requested", "disputed"], to: "cancelled", event: "deal_cancelled", message: "取引をキャンセルしました。返金・出品復帰について運営が対応します。" },
  } as const;
  const next = transition[input.action];
  if (!next.from.includes(deal.status as never)) throw new Error("現在の取引段階では、この操作は実行できません。");
  const now = new Date();
  await db.update(transactions).set({ status: next.to, ...(input.action === "payment_confirm" ? { paymentReviewedAt: now } : {}), ...(input.action === "release_to_buyer" ? { deliveredAt: now } : {}), ...(input.action === "complete_payout" ? { completedAt: now } : {}) }).where(eq(transactions.id, input.dealId));
  if (input.action === "review_credentials") await db.update(credentialVault).set({ reviewedAt: now }).where(eq(credentialVault.transactionId, input.dealId));
  if (input.action === "release_to_buyer") await db.update(credentialVault).set({ releasedAt: now }).where(eq(credentialVault.transactionId, input.dealId));
  if (input.action === "cancel") await db.update(listings).set({ state: "active" }).where(eq(listings.id, deal.listingId));
  await createEvent(input.dealId, actor.id, next.event, input.note?.trim() || next.message);
  await createAudit(actor.id, input.action, "transaction", input.dealId, input.note?.trim() || null);
}

export async function revealCredentialsForOperator(actor: { id: number }, dealId: string) {
  const db = await requireDb();
  const vault = await db.select().from(credentialVault).where(eq(credentialVault.transactionId, dealId)).limit(1);
  if (!vault[0]) throw new Error("アカウント情報はまだ提出されていません。");
  await createAudit(actor.id, "credentials_viewed", "transaction", dealId, "運営担当者が暗号化情報を閲覧");
  return decryptCredential(vault[0]);
}

export async function getAdminOverview() {
  const db = await requireDb();
  const [pendingListings] = await db.select({ count: sql<number>`count(*)` }).from(listings).where(eq(listings.verification, "pending"));
  const [activeDeals] = await db.select({ count: sql<number>`count(*)` }).from(transactions).where(sql`${transactions.status} NOT IN ('completed', 'cancelled')`);
  const [disputes] = await db.select({ count: sql<number>`count(*)` }).from(transactions).where(eq(transactions.status, "disputed"));
  const recentListings = await db.select().from(listings).where(eq(listings.verification, "pending")).orderBy(desc(listings.createdAt)).limit(20);
  const recentDeals = await db.select({ id: transactions.id, status: transactions.status, amountYen: transactions.amountYen, createdAt: transactions.createdAt, xboxId: listings.xboxId, buyerId: transactions.buyerId, sellerId: transactions.sellerId }).from(transactions).innerJoin(listings, eq(listings.id, transactions.listingId)).orderBy(desc(transactions.updatedAt)).limit(30);
  return { pendingListings: Number(pendingListings?.count ?? 0), activeDeals: Number(activeDeals?.count ?? 0), disputes: Number(disputes?.count ?? 0), recentListings, recentDeals };
}

export async function getAdminUsers() {
  const db = await requireDb();
  return db.select({ id: users.id, name: users.name, email: users.email, role: users.role, createdAt: users.createdAt, lastSignedIn: users.lastSignedIn, handle: userProfiles.handle }).from(users).leftJoin(userProfiles, eq(userProfiles.userId, users.id)).orderBy(desc(users.createdAt)).limit(200);
}

export async function setUserRole(actor: { id: number; openId: string }, userId: number, role: "user" | "operator" | "admin") {
  const db = await requireDb();
  const firstAdmin = await db.select({ id: users.id }).from(users).where(eq(users.role, "admin")).orderBy(users.createdAt).limit(1);
  if (firstAdmin[0]?.id !== actor.id) throw new Error("最初の管理者のみが権限を変更できます。");
  if (actor.id === userId && role !== "admin") throw new Error("自分自身の管理者権限は解除できません。");
  await db.update(users).set({ role }).where(eq(users.id, userId));
  await createAudit(actor.id, "role_changed", "user", String(userId), role);
}

export async function createAdminInvite(actor: { id: number }, input: { targetRole: "operator" | "admin"; expiresInDays: number }) {
  const db = await requireDb();
  const code = `XID-${input.targetRole === "admin" ? "ADMIN" : "OPS"}-${nanoid(12).toUpperCase()}`;
  const id = nanoid(16);
  const expiresAt = new Date(Date.now() + input.expiresInDays * 24 * 60 * 60 * 1000);
  await db.insert(adminInviteCodes).values({ id, codeHash: hashAdminCode(code), targetRole: input.targetRole, createdBy: actor.id, expiresAt });
  await createAudit(actor.id, "invite_created", "admin_invite", id, input.targetRole);
  return { code, expiresAt };
}

/** A hashed bootstrap code is accepted only once; the plaintext never enters the repository. */
export async function redeemAdminCode(user: { id: number }, code: string) {
  const db = await requireDb();
  const normalized = code.trim().toUpperCase();
  const codeHash = hashAdminCode(normalized);
  const bootstrapHash = "fe2508aceee447d4b1fa36e77cc5f22eba83cf86412ccfe8ec72ac74e6d1c98e";
  if (codeHash === bootstrapHash) {
    try {
      await db.insert(adminInviteCodes).values({ id: "bootstrap-admin-code", codeHash, targetRole: "admin", usedBy: user.id, usedAt: new Date(), expiresAt: new Date("2036-01-01T00:00:00Z") });
    } catch {
      throw new Error("この管理者コードはすでに使用されています。");
    }
    await db.update(users).set({ role: "admin" }).where(eq(users.id, user.id));
    await createAudit(user.id, "bootstrap_admin_redeemed", "user", String(user.id), "初期管理者コード");
    return { role: "admin" as const };
  }
  const invite = await db.select().from(adminInviteCodes).where(and(eq(adminInviteCodes.codeHash, codeHash), isNull(adminInviteCodes.usedAt), gt(adminInviteCodes.expiresAt, new Date()))).limit(1);
  if (!invite[0]) throw new Error("管理者コードが無効、有効期限切れ、または使用済みです。");
  const claimed = await db.update(adminInviteCodes).set({ usedBy: user.id, usedAt: new Date() }).where(and(eq(adminInviteCodes.id, invite[0].id), isNull(adminInviteCodes.usedAt)));
  const changed = Array.isArray(claimed) ? (claimed[0] as { affectedRows?: number })?.affectedRows : 1;
  if (changed !== 1) throw new Error("管理者コードはすでに使用されています。");
  await db.update(users).set({ role: invite[0].targetRole }).where(eq(users.id, user.id));
  await createAudit(user.id, "admin_invite_redeemed", "user", String(user.id), invite[0].targetRole);
  return { role: invite[0].targetRole };
}

async function createEvent(transactionId: string, actorId: number | null, type: string, detail: string) {
  const db = await requireDb();
  await db.insert(transactionEvents).values({ id: nanoid(16), transactionId, actorId, type, detail });
}

async function createAudit(actorId: number | null, action: string, subjectType: string, subjectId: string, detail: string | null) {
  const db = await requireDb();
  await db.insert(auditLogs).values({ id: nanoid(16), actorId, action, subjectType, subjectId, detail });
}
