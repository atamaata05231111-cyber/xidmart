import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import {
  acceptDelivery,
  browseListings,
  createAdminInvite,
  createDeal,
  createListing,
  getAdminOverview,
  getAdminUsers,
  getDealDetail,
  getListing,
  getMyDeals,
  getMyListings,
  getMyProfile,
  openDispute,
  operatorUpdateDeal,
  operatorVerifyListing,
  redeemAdminCode,
  revealCredentialsForOperator,
  saveMyProfile,
  sendDealMessage,
  setUserRole,
  submitCredentials,
  submitPaymentProof,
} from "./db";
import { isValidXboxId } from "./security";

const categorySchema = z.enum(["4c", "4l", "3c", "3l", "2c", "2l", "world", "standard", "hive"]);
const imageSchema = z.object({ fileName: z.string().min(1).max(120), mimeType: z.enum(["image/jpeg", "image/png", "image/webp"]), base64: z.string().min(20) });

function domainError(error: unknown): never {
  if (error instanceof TRPCError) throw error;
  throw new TRPCError({ code: "BAD_REQUEST", message: error instanceof Error ? error.message : "処理に失敗しました。" });
}

const operatorProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (!["operator", "admin"].includes(ctx.user.role)) throw new TRPCError({ code: "FORBIDDEN", message: "運営権限が必要です。" });
  return next();
});

const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "管理者権限が必要です。" });
  return next();
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  marketplace: router({
    browse: publicProcedure.input(z.object({ query: z.string().max(30).optional(), category: categorySchema.optional(), idLength: z.number().int().min(1).max(15).optional(), characterType: z.enum(["alphabet", "alphanumeric", "mixed"]).optional() }).optional()).query(async ({ input }) => {
      try { return await browseListings(input ?? {}); } catch (error) { domainError(error); }
    }),
    listing: publicProcedure.input(z.object({ id: z.string().min(1).max(32) })).query(async ({ input }) => {
      try { return await getListing(input.id); } catch (error) { domainError(error); }
    }),
    metrics: publicProcedure.query(async () => {
      try { return { feeRate: 10, categories: categorySchema.options }; } catch (error) { domainError(error); }
    }),
  }),
  profile: router({
    mine: protectedProcedure.query(async ({ ctx }) => {
      try { return await getMyProfile(ctx.user); } catch (error) { domainError(error); }
    }),
    update: protectedProcedure.input(z.object({ handle: z.string().trim().min(2, "表示名は2文字以上にしてください。").max(32), bio: z.string().max(300).optional(), isPublic: z.boolean() })).mutation(async ({ ctx, input }) => {
      try { return await saveMyProfile(ctx.user, input); } catch (error) { domainError(error); }
    }),
  }),
  listings: router({
    mine: protectedProcedure.query(async ({ ctx }) => {
      try { return await getMyListings(ctx.user.id); } catch (error) { domainError(error); }
    }),
    create: protectedProcedure.input(z.object({ xboxId: z.string().trim().min(1).max(15), category: categorySchema, description: z.string().trim().min(20, "説明は20文字以上にしてください。").max(1000), priceYen: z.number().int().min(500).max(10000000), screenshot: imageSchema }).superRefine((value, refineCtx) => {
      if (!isValidXboxId(value.xboxId)) refineCtx.addIssue({ code: "custom", message: "IDは英字で始め、数字・記号を先頭に付けず、15文字以内にしてください。", path: ["xboxId"] });
    })).mutation(async ({ ctx, input }) => {
      try { return await createListing(ctx.user, input); } catch (error) { domainError(error); }
    }),
  }),
  deals: router({
    mine: protectedProcedure.query(async ({ ctx }) => {
      try { return await getMyDeals(ctx.user.id); } catch (error) { domainError(error); }
    }),
    detail: protectedProcedure.input(z.object({ id: z.string().min(1).max(32) })).query(async ({ ctx, input }) => {
      try { return await getDealDetail(ctx.user, input.id); } catch (error) { domainError(error); }
    }),
    create: protectedProcedure.input(z.object({ listingId: z.string().min(1).max(32) })).mutation(async ({ ctx, input }) => {
      try { return await createDeal(ctx.user, input.listingId); } catch (error) { domainError(error); }
    }),
    submitPayment: protectedProcedure.input(z.object({ dealId: z.string().min(1).max(32), reference: z.string().trim().min(3).max(120), screenshot: imageSchema })).mutation(async ({ ctx, input }) => {
      try { return await submitPaymentProof(ctx.user, input); } catch (error) { domainError(error); }
    }),
    submitCredentials: protectedProcedure.input(z.object({ dealId: z.string().min(1).max(32), credentials: z.string().trim().min(8).max(4000) })).mutation(async ({ ctx, input }) => {
      try { return await submitCredentials(ctx.user, input); } catch (error) { domainError(error); }
    }),
    sendMessage: protectedProcedure.input(z.object({ dealId: z.string().min(1).max(32), body: z.string().trim().min(1).max(2000), operatorOnly: z.boolean().optional() })).mutation(async ({ ctx, input }) => {
      try { return await sendDealMessage(ctx.user, input); } catch (error) { domainError(error); }
    }),
    acceptDelivery: protectedProcedure.input(z.object({ dealId: z.string().min(1).max(32) })).mutation(async ({ ctx, input }) => {
      try { return await acceptDelivery(ctx.user, input.dealId); } catch (error) { domainError(error); }
    }),
    dispute: protectedProcedure.input(z.object({ dealId: z.string().min(1).max(32), reason: z.string().trim().min(10).max(600) })).mutation(async ({ ctx, input }) => {
      try { return await openDispute(ctx.user, input.dealId, input.reason); } catch (error) { domainError(error); }
    }),
  }),
  operator: router({
    verifyListing: operatorProcedure.input(z.object({ listingId: z.string().min(1).max(32), approve: z.boolean(), note: z.string().max(500).optional() })).mutation(async ({ ctx, input }) => {
      try { return await operatorVerifyListing(ctx.user, input.listingId, input.approve, input.note); } catch (error) { domainError(error); }
    }),
    updateDeal: operatorProcedure.input(z.object({ dealId: z.string().min(1).max(32), action: z.enum(["payment_confirm", "request_credentials", "review_credentials", "release_to_buyer", "complete_payout", "cancel"]), note: z.string().max(500).optional() })).mutation(async ({ ctx, input }) => {
      try { return await operatorUpdateDeal(ctx.user, input); } catch (error) { domainError(error); }
    }),
    revealCredentials: operatorProcedure.input(z.object({ dealId: z.string().min(1).max(32) })).mutation(async ({ ctx, input }) => {
      try { return await revealCredentialsForOperator(ctx.user, input.dealId); } catch (error) { domainError(error); }
    }),
  }),
  admin: router({
    overview: operatorProcedure.query(async () => {
      try { return await getAdminOverview(); } catch (error) { domainError(error); }
    }),
    users: adminProcedure.query(async () => {
      try { return await getAdminUsers(); } catch (error) { domainError(error); }
    }),
    changeRole: adminProcedure.input(z.object({ userId: z.number().int().positive(), role: z.enum(["user", "operator", "admin"]) })).mutation(async ({ ctx, input }) => {
      try { return await setUserRole(ctx.user, input.userId, input.role); } catch (error) { domainError(error); }
    }),
    createInvite: adminProcedure.input(z.object({ targetRole: z.enum(["operator", "admin"]), expiresInDays: z.number().int().min(1).max(90) })).mutation(async ({ ctx, input }) => {
      try { return await createAdminInvite(ctx.user, input); } catch (error) { domainError(error); }
    }),
    redeemCode: protectedProcedure.input(z.object({ code: z.string().trim().min(8).max(80) })).mutation(async ({ ctx, input }) => {
      try { return await redeemAdminCode(ctx.user, input.code); } catch (error) { domainError(error); }
    }),
  }),
});

export type AppRouter = typeof appRouter;
