import { afterEach, describe, expect, it } from "vitest";
import { decryptCredential, encryptCredential, hashAdminCode, isValidXboxId } from "./security";

const previousSecret = process.env.JWT_SECRET;
afterEach(() => { process.env.JWT_SECRET = previousSecret; });

describe("credential vault encryption", () => {
  it("round-trips an account payload without storing plaintext", () => {
    process.env.JWT_SECRET = "test-secret-for-vault";
    const payload = "owner@example.com\nCorrectHorseBatteryStaple";
    const encrypted = encryptCredential(payload);
    expect(encrypted.cipherText).not.toContain("CorrectHorse");
    expect(decryptCredential(encrypted)).toBe(payload);
  });
});

describe("Xbox ID validation", () => {
  it("requires a leading alphabetic character and no more than 15 characters", () => {
    expect(isValidXboxId("A1b2")).toBe(true);
    expect(isValidXboxId("1abc")).toBe(false);
    expect(isValidXboxId("_abc")).toBe(false);
    expect(isValidXboxId("abcdefghijklmnop")).toBe(false);
  });
});

describe("administrator code handling", () => {
  it("creates deterministic irreversible hashes", () => {
    expect(hashAdminCode("XID-ADMIN-TEST")).toMatch(/^[a-f0-9]{64}$/);
    expect(hashAdminCode("XID-ADMIN-TEST")).toBe(hashAdminCode("XID-ADMIN-TEST"));
  });
});
