import {
  boolean,
  index,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";

export const userRoles = ["user", "operator", "admin"] as const;
export const listingCategories = ["4c", "4l", "3c", "3l", "2c", "2l", "world", "standard", "hive"] as const;
export const listingStates = ["active", "reserved", "sold", "paused", "rejected"] as const;
export const verificationStates = ["pending", "approved", "rejected"] as const;
export const dealStatuses = [
  "payment_pending",
  "payment_review",
  "credentials_requested",
  "credentials_submitted",
  "operator_review",
  "delivery_ready",
  "delivered",
  "acceptance_pending",
  "completed",
  "cancelled",
  "disputed",
] as const;

/** Identity record created by the platform authentication flow. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", userRoles).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const userProfiles = mysqlTable(
  "userProfiles",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
    handle: varchar("handle", { length: 32 }).notNull(),
    bio: varchar("bio", { length: 300 }),
    isPublic: boolean("isPublic").default(true).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({ userUnique: uniqueIndex("userProfiles_user_unique").on(table.userId) }),
);

export const listings = mysqlTable(
  "listings",
  {
    id: varchar("id", { length: 32 }).primaryKey(),
    sellerId: int("sellerId").notNull().references(() => users.id, { onDelete: "cascade" }),
    xboxId: varchar("xboxId", { length: 15 }).notNull(),
    category: mysqlEnum("category", listingCategories).notNull(),
    description: varchar("description", { length: 1000 }).notNull(),
    priceYen: int("priceYen").notNull(),
    screenshotUrl: varchar("screenshotUrl", { length: 512 }).notNull(),
    screenshotKey: varchar("screenshotKey", { length: 512 }).notNull(),
    verification: mysqlEnum("verification", verificationStates).default("pending").notNull(),
    verificationNote: varchar("verificationNote", { length: 500 }),
    state: mysqlEnum("state", listingStates).default("active").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    sellerIdx: index("listings_seller_idx").on(table.sellerId),
    browseIdx: index("listings_browse_idx").on(table.state, table.verification, table.category),
  }),
);

export const transactions = mysqlTable(
  "transactions",
  {
    id: varchar("id", { length: 32 }).primaryKey(),
    listingId: varchar("listingId", { length: 32 }).notNull().references(() => listings.id),
    buyerId: int("buyerId").notNull().references(() => users.id),
    sellerId: int("sellerId").notNull().references(() => users.id),
    amountYen: int("amountYen").notNull(),
    feeYen: int("feeYen").notNull(),
    payoutYen: int("payoutYen").notNull(),
    status: mysqlEnum("status", dealStatuses).default("payment_pending").notNull(),
    paymentReference: varchar("paymentReference", { length: 120 }),
    paymentProofUrl: varchar("paymentProofUrl", { length: 512 }),
    paymentProofKey: varchar("paymentProofKey", { length: 512 }),
    paymentReviewedAt: timestamp("paymentReviewedAt"),
    deliveredAt: timestamp("deliveredAt"),
    completedAt: timestamp("completedAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    buyerIdx: index("transactions_buyer_idx").on(table.buyerId, table.status),
    sellerIdx: index("transactions_seller_idx").on(table.sellerId, table.status),
    listingUnique: uniqueIndex("transactions_listing_unique").on(table.listingId),
  }),
);

/** Credentials are encrypted server-side and are never returned to buyers automatically. */
export const credentialVault = mysqlTable(
  "credentialVault",
  {
    id: varchar("id", { length: 32 }).primaryKey(),
    transactionId: varchar("transactionId", { length: 32 }).notNull().references(() => transactions.id, { onDelete: "cascade" }),
    cipherText: text("cipherText").notNull(),
    iv: varchar("iv", { length: 64 }).notNull(),
    authTag: varchar("authTag", { length: 64 }).notNull(),
    submittedBy: int("submittedBy").notNull().references(() => users.id),
    submittedAt: timestamp("submittedAt").defaultNow().notNull(),
    reviewedAt: timestamp("reviewedAt"),
    releasedAt: timestamp("releasedAt"),
  },
  table => ({ transactionUnique: uniqueIndex("credential_transaction_unique").on(table.transactionId) }),
);

export const transactionMessages = mysqlTable(
  "transactionMessages",
  {
    id: varchar("id", { length: 32 }).primaryKey(),
    transactionId: varchar("transactionId", { length: 32 }).notNull().references(() => transactions.id, { onDelete: "cascade" }),
    senderId: int("senderId").notNull().references(() => users.id),
    body: varchar("body", { length: 2000 }).notNull(),
    visibility: mysqlEnum("visibility", ["participants", "operator_only"]).default("participants").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({ dealIdx: index("transactionMessages_deal_idx").on(table.transactionId, table.createdAt) }),
);

export const transactionEvents = mysqlTable(
  "transactionEvents",
  {
    id: varchar("id", { length: 32 }).primaryKey(),
    transactionId: varchar("transactionId", { length: 32 }).notNull().references(() => transactions.id, { onDelete: "cascade" }),
    actorId: int("actorId").references(() => users.id),
    type: varchar("type", { length: 64 }).notNull(),
    detail: varchar("detail", { length: 500 }).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({ dealIdx: index("transactionEvents_deal_idx").on(table.transactionId, table.createdAt) }),
);

/** One-time administrator or operator invitation codes are stored as SHA-256 hashes. */
export const adminInviteCodes = mysqlTable(
  "adminInviteCodes",
  {
    id: varchar("id", { length: 32 }).primaryKey(),
    codeHash: varchar("codeHash", { length: 64 }).notNull(),
    targetRole: mysqlEnum("targetRole", ["operator", "admin"]).default("operator").notNull(),
    createdBy: int("createdBy").references(() => users.id),
    usedBy: int("usedBy").references(() => users.id),
    usedAt: timestamp("usedAt"),
    expiresAt: timestamp("expiresAt").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({ codeIdx: uniqueIndex("adminInviteCodes_hash_unique").on(table.codeHash) }),
);

export const auditLogs = mysqlTable(
  "auditLogs",
  {
    id: varchar("id", { length: 32 }).primaryKey(),
    actorId: int("actorId").references(() => users.id),
    action: varchar("action", { length: 80 }).notNull(),
    subjectType: varchar("subjectType", { length: 60 }).notNull(),
    subjectId: varchar("subjectId", { length: 64 }).notNull(),
    detail: varchar("detail", { length: 500 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({ createdIdx: index("auditLogs_created_idx").on(table.createdAt) }),
);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
