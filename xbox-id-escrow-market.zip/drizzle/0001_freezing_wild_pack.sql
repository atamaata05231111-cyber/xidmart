CREATE TABLE `adminInviteCodes` (
	`id` varchar(32) NOT NULL,
	`codeHash` varchar(64) NOT NULL,
	`targetRole` enum('operator','admin') NOT NULL DEFAULT 'operator',
	`createdBy` int,
	`usedBy` int,
	`usedAt` timestamp,
	`expiresAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `adminInviteCodes_id` PRIMARY KEY(`id`),
	CONSTRAINT `adminInviteCodes_hash_unique` UNIQUE(`codeHash`)
);
--> statement-breakpoint
CREATE TABLE `auditLogs` (
	`id` varchar(32) NOT NULL,
	`actorId` int,
	`action` varchar(80) NOT NULL,
	`subjectType` varchar(60) NOT NULL,
	`subjectId` varchar(64) NOT NULL,
	`detail` varchar(500),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `auditLogs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `credentialVault` (
	`id` varchar(32) NOT NULL,
	`transactionId` varchar(32) NOT NULL,
	`cipherText` text NOT NULL,
	`iv` varchar(64) NOT NULL,
	`authTag` varchar(64) NOT NULL,
	`submittedBy` int NOT NULL,
	`submittedAt` timestamp NOT NULL DEFAULT (now()),
	`reviewedAt` timestamp,
	`releasedAt` timestamp,
	CONSTRAINT `credentialVault_id` PRIMARY KEY(`id`),
	CONSTRAINT `credential_transaction_unique` UNIQUE(`transactionId`)
);
--> statement-breakpoint
CREATE TABLE `listings` (
	`id` varchar(32) NOT NULL,
	`sellerId` int NOT NULL,
	`xboxId` varchar(15) NOT NULL,
	`category` enum('4c','4l','3c','3l','2c','2l','world','standard','hive') NOT NULL,
	`description` varchar(1000) NOT NULL,
	`priceYen` int NOT NULL,
	`screenshotUrl` varchar(512) NOT NULL,
	`screenshotKey` varchar(512) NOT NULL,
	`verification` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
	`verificationNote` varchar(500),
	`state` enum('active','reserved','sold','paused','rejected') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `listings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `transactionEvents` (
	`id` varchar(32) NOT NULL,
	`transactionId` varchar(32) NOT NULL,
	`actorId` int,
	`type` varchar(64) NOT NULL,
	`detail` varchar(500) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `transactionEvents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `transactionMessages` (
	`id` varchar(32) NOT NULL,
	`transactionId` varchar(32) NOT NULL,
	`senderId` int NOT NULL,
	`body` varchar(2000) NOT NULL,
	`visibility` enum('participants','operator_only') NOT NULL DEFAULT 'participants',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `transactionMessages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `transactions` (
	`id` varchar(32) NOT NULL,
	`listingId` varchar(32) NOT NULL,
	`buyerId` int NOT NULL,
	`sellerId` int NOT NULL,
	`amountYen` int NOT NULL,
	`feeYen` int NOT NULL,
	`payoutYen` int NOT NULL,
	`status` enum('payment_pending','payment_review','credentials_requested','credentials_submitted','operator_review','delivery_ready','delivered','acceptance_pending','completed','cancelled','disputed') NOT NULL DEFAULT 'payment_pending',
	`paymentReference` varchar(120),
	`paymentProofUrl` varchar(512),
	`paymentProofKey` varchar(512),
	`paymentReviewedAt` timestamp,
	`deliveredAt` timestamp,
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `transactions_id` PRIMARY KEY(`id`),
	CONSTRAINT `transactions_listing_unique` UNIQUE(`listingId`)
);
--> statement-breakpoint
CREATE TABLE `userProfiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`handle` varchar(32) NOT NULL,
	`bio` varchar(300),
	`isPublic` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `userProfiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `userProfiles_user_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('user','operator','admin') NOT NULL DEFAULT 'user';--> statement-breakpoint
ALTER TABLE `adminInviteCodes` ADD CONSTRAINT `adminInviteCodes_createdBy_users_id_fk` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `adminInviteCodes` ADD CONSTRAINT `adminInviteCodes_usedBy_users_id_fk` FOREIGN KEY (`usedBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `auditLogs` ADD CONSTRAINT `auditLogs_actorId_users_id_fk` FOREIGN KEY (`actorId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `credentialVault` ADD CONSTRAINT `credentialVault_transactionId_transactions_id_fk` FOREIGN KEY (`transactionId`) REFERENCES `transactions`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `credentialVault` ADD CONSTRAINT `credentialVault_submittedBy_users_id_fk` FOREIGN KEY (`submittedBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `listings` ADD CONSTRAINT `listings_sellerId_users_id_fk` FOREIGN KEY (`sellerId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `transactionEvents` ADD CONSTRAINT `transactionEvents_transactionId_transactions_id_fk` FOREIGN KEY (`transactionId`) REFERENCES `transactions`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `transactionEvents` ADD CONSTRAINT `transactionEvents_actorId_users_id_fk` FOREIGN KEY (`actorId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `transactionMessages` ADD CONSTRAINT `transactionMessages_transactionId_transactions_id_fk` FOREIGN KEY (`transactionId`) REFERENCES `transactions`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `transactionMessages` ADD CONSTRAINT `transactionMessages_senderId_users_id_fk` FOREIGN KEY (`senderId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `transactions` ADD CONSTRAINT `transactions_listingId_listings_id_fk` FOREIGN KEY (`listingId`) REFERENCES `listings`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `transactions` ADD CONSTRAINT `transactions_buyerId_users_id_fk` FOREIGN KEY (`buyerId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `transactions` ADD CONSTRAINT `transactions_sellerId_users_id_fk` FOREIGN KEY (`sellerId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `userProfiles` ADD CONSTRAINT `userProfiles_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `auditLogs_created_idx` ON `auditLogs` (`createdAt`);--> statement-breakpoint
CREATE INDEX `listings_seller_idx` ON `listings` (`sellerId`);--> statement-breakpoint
CREATE INDEX `listings_browse_idx` ON `listings` (`state`,`verification`,`category`);--> statement-breakpoint
CREATE INDEX `transactionEvents_deal_idx` ON `transactionEvents` (`transactionId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `transactionMessages_deal_idx` ON `transactionMessages` (`transactionId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `transactions_buyer_idx` ON `transactions` (`buyerId`,`status`);--> statement-breakpoint
CREATE INDEX `transactions_seller_idx` ON `transactions` (`sellerId`,`status`);