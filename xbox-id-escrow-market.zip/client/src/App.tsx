import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import AdminDashboard from "./pages/AdminDashboard";
import Dashboard from "./pages/Dashboard";
import DealRoom from "./pages/DealRoom";
import Home from "./pages/Home";
import HowItWorks from "./pages/HowItWorks";
import ListingDetail from "./pages/ListingDetail";

function Router() {
  return <Switch>
    <Route path="/" component={Home} />
    <Route path="/how-it-works" component={HowItWorks} />
    <Route path="/listings/:id" component={ListingDetail} />
    <Route path="/dashboard" component={Dashboard} />
    <Route path="/deals/:id" component={DealRoom} />
    <Route path="/admin" component={AdminDashboard} />
    <Route path="/404" component={NotFound} />
    <Route component={NotFound} />
  </Switch>;
}

export default function App() {
  return <ErrorBoundary><ThemeProvider defaultTheme="light"><TooltipProvider><Toaster richColors position="top-center"/><Router /></TooltipProvider></ThemeProvider></ErrorBoundary>;
}
