import { startLogin } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Link, useLocation } from "wouter";
import { BadgeCheck, CircleHelp, LayoutDashboard, Menu, ShieldCheck, Store, UserRound, X } from "lucide-react";
import { useState } from "react";

type ShellProps = { children: React.ReactNode };

const navItems = [
  { href: "/", label: "探す", icon: Store },
  { href: "/how-it-works", label: "安全な取引", icon: ShieldCheck },
];

export function MarketplaceShell({ children }: ShellProps) {
  const { user, isAuthenticated, loading, logout } = useAuth();
  const [location] = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const signedIn = isAuthenticated && !!user;

  const close = () => setMenuOpen(false);
  return (
    <div className="min-h-screen bg-[#f6f7f4] text-slate-950">
      <div className="h-1 bg-gradient-to-r from-[#107c10] via-[#75b900] to-[#107c10]" />
      <header className="sticky top-0 z-40 border-b border-slate-200/80 bg-white/95 backdrop-blur">
        <div className="container flex h-[72px] items-center justify-between gap-4">
          <Link href="/" className="group flex shrink-0 items-center gap-3" onClick={close}>
            <div className="grid size-10 place-items-center rounded-xl bg-[#107c10] font-black tracking-tighter text-white shadow-[0_8px_18px_rgba(16,124,16,.25)] transition-transform duration-150 group-hover:-rotate-3">X</div>
            <div className="leading-tight">
              <div className="text-[15px] font-black tracking-tight">X-ID MARKET</div>
              <div className="text-[10px] font-bold tracking-[.14em] text-[#107c10]">SAFE ESCROW SERVICE</div>
            </div>
          </Link>
          <nav className="hidden items-center gap-1 md:flex">
            {navItems.map(item => <Link key={item.href} href={item.href} className={`rounded-lg px-4 py-2 text-sm font-semibold transition-colors ${location === item.href ? "bg-[#edf7eb] text-[#107c10]" : "text-slate-600 hover:bg-slate-100 hover:text-slate-950"}`}><span className="flex items-center gap-2"><item.icon size={16} />{item.label}</span></Link>)}
          </nav>
          <div className="hidden items-center gap-2 md:flex">
            {signedIn ? <>
              {user.role !== "user" && <Link href="/admin"><Button variant="ghost" size="sm" className="gap-2 text-[#107c10]"><ShieldCheck size={16} />運営</Button></Link>}
              <Link href="/dashboard"><Button variant="outline" size="sm" className="gap-2 border-slate-300"><UserRound size={16} />マイページ</Button></Link>
              <Button variant="ghost" size="sm" onClick={() => logout()} className="text-slate-500">ログアウト</Button>
            </> : <Button disabled={loading} onClick={() => startLogin()} className="bg-[#107c10] font-bold hover:bg-[#0b5f0b]">無料で登録・ログイン</Button>}
          </div>
          <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setMenuOpen(open => !open)} aria-label="メニューを開く">{menuOpen ? <X /> : <Menu />}</Button>
        </div>
        {menuOpen && <div className="border-t border-slate-100 bg-white px-4 py-3 shadow-lg md:hidden">
          <div className="flex flex-col gap-1">
            {navItems.map(item => <Link key={item.href} href={item.href} onClick={close} className={`rounded-lg px-4 py-3 text-sm font-semibold ${location === item.href ? "bg-[#edf7eb] text-[#107c10]" : "text-slate-700"}`}>{item.label}</Link>)}
            {signedIn ? <>
              <Link href="/dashboard" onClick={close} className="rounded-lg px-4 py-3 text-sm font-semibold text-slate-700">マイページ</Link>
              {user.role !== "user" && <Link href="/admin" onClick={close} className="rounded-lg px-4 py-3 text-sm font-semibold text-[#107c10]">運営ダッシュボード</Link>}
              <Button variant="ghost" className="justify-start px-4" onClick={() => { close(); logout(); }}>ログアウト</Button>
            </> : <Button onClick={() => startLogin()} className="mt-2 bg-[#107c10]">無料で登録・ログイン</Button>}
          </div>
        </div>}
      </header>
      {children}
      <footer className="mt-16 border-t border-slate-200 bg-white">
        <div className="container grid gap-8 py-10 md:grid-cols-[1.4fr_1fr_1fr]">
          <div><div className="mb-2 text-lg font-black">X-ID MARKET</div><p className="max-w-sm text-sm leading-6 text-slate-500">取引ごとに運営が確認・仲介する、ID取引専用のマーケットプレイスです。</p></div>
          <div><div className="mb-3 text-sm font-bold">ご利用前に</div><div className="space-y-2 text-sm text-slate-500"><Link href="/how-it-works">安全な取引の流れ</Link><div>禁止行為・利用規約</div><div>プライバシーポリシー</div></div></div>
          <div className="rounded-xl bg-[#edf7eb] p-4"><div className="mb-1 flex items-center gap-2 text-sm font-bold text-[#107c10]"><BadgeCheck size={16} />運営仲介</div><p className="text-xs leading-5 text-slate-600">売り手・買い手間で認証情報を直接共有しない設計です。</p></div>
        </div>
        <div className="border-t border-slate-100 py-4 text-center text-xs text-slate-400">© 2026 X-ID MARKET · Not affiliated with Microsoft or Xbox.</div>
      </footer>
    </div>
  );
}

export function PageHeader({ eyebrow, title, children }: { eyebrow: string; title: string; children?: React.ReactNode }) {
  return <section className="border-b border-slate-200 bg-white"><div className="container py-10 md:py-14"><div className="mb-3 text-xs font-extrabold tracking-[.18em] text-[#107c10]">{eyebrow}</div><h1 className="text-3xl font-black tracking-tight text-slate-950 md:text-4xl">{title}</h1>{children}</div></section>;
}

export function LoginWall({ title = "ログインして続ける" }: { title?: string }) {
  const { loading } = useAuth();
  return <div className="mx-auto my-16 max-w-md rounded-2xl border border-slate-200 bg-white p-8 text-center shadow-sm"><div className="mx-auto mb-4 grid size-12 place-items-center rounded-full bg-[#edf7eb] text-[#107c10]"><CircleHelp /></div><h2 className="text-xl font-black">{title}</h2><p className="mt-2 text-sm leading-6 text-slate-500">メールアドレスに紐づくアカウントでログインすると、出品・購入・取引チャットを利用できます。</p><Button disabled={loading} onClick={() => startLogin()} className="mt-6 w-full bg-[#107c10] hover:bg-[#0b5f0b]">登録・ログイン</Button></div>;
}
