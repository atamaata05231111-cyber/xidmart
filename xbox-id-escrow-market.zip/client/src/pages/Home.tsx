import { MarketplaceShell } from "@/components/MarketplaceShell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { trpc } from "@/lib/trpc";
import { BadgeCheck, ChevronRight, CircleDollarSign, FileCheck2, Search, ShieldCheck, Sparkles, UserRoundCheck } from "lucide-react";
import { Link } from "wouter";
import { useMemo, useState } from "react";

const categoryLabels: Record<string, string> = { "4c": "4c", "4l": "4l", "3c": "3c", "3l": "3l", "2c": "2c", "2l": "2l", world: "world", standard: "普通のID", hive: "hive" };

export default function Home() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<string>("all");
  const [idLength, setIdLength] = useState<string>("all");
  const [characterType, setCharacterType] = useState<string>("all");
  const filter = useMemo(() => ({ query: query || undefined, category: category === "all" ? undefined : category as any, idLength: idLength === "all" ? undefined : Number(idLength), characterType: characterType === "all" ? undefined : characterType as any }), [query, category, idLength, characterType]);
  const { data: listings, isLoading } = trpc.marketplace.browse.useQuery(filter);

  return <MarketplaceShell>
    <section className="relative overflow-hidden bg-[#0b170c] text-white">
      <div className="absolute inset-0 opacity-30" style={{ backgroundImage: "radial-gradient(circle at 72% 24%, #75b900 0, transparent 24%), radial-gradient(circle at 15% 90%, #107c10 0, transparent 32%)" }} />
      <div className="container relative grid gap-10 py-16 md:grid-cols-[1.1fr_.9fr] md:py-24">
        <div><div className="mb-5 inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3 py-1.5 text-xs font-bold tracking-wide text-[#b6e66b]"><ShieldCheck size={14} />運営確認・仲介型マーケット</div><h1 className="max-w-2xl text-4xl font-black leading-[1.12] tracking-tight md:text-6xl">大切なID取引を、<br /><span className="text-[#9bdb3b]">安心できる手順</span>で。</h1><p className="mt-6 max-w-lg text-base leading-7 text-slate-300">IDの所有確認からアカウント情報の受け渡し、出品者への精算まで、取引の各段階を運営が仲介します。</p><div className="mt-8 flex flex-wrap gap-3"><Link href="#market"><Button size="lg" className="bg-[#75b900] font-extrabold text-[#102307] hover:bg-[#9ad330]">IDを探す<ChevronRight size={18} /></Button></Link><Link href="/how-it-works"><Button size="lg" variant="outline" className="border-white/30 bg-white/5 font-bold text-white hover:bg-white/15 hover:text-white">取引の流れ</Button></Link></div></div>
        <div className="self-end rounded-2xl border border-white/10 bg-white/10 p-5 backdrop-blur-sm"><div className="mb-4 flex items-center justify-between"><span className="text-sm font-bold">安心の3つの約束</span><Sparkles className="text-[#9bdb3b]" size={18} /></div><div className="space-y-3">{[["所有確認", "出品前に、IDを所有している画面を確認"], ["認証情報の保護", "情報は運営専用の暗号化保管庫へ提出"], ["段階的な決済", "確認完了後にのみ、出品者へ精算"]].map(([title, text], index) => <div key={title} className="flex gap-3 rounded-xl bg-black/15 p-3"><div className="grid size-7 shrink-0 place-items-center rounded-lg bg-[#75b900] text-xs font-black text-[#102307]">0{index + 1}</div><div><div className="text-sm font-bold">{title}</div><div className="mt-0.5 text-xs leading-5 text-slate-300">{text}</div></div></div>)}</div></div>
      </div>
    </section>
    <main id="market" className="container py-10 md:py-14">
      <div className="mb-7 flex flex-col justify-between gap-4 md:flex-row md:items-end"><div><div className="text-xs font-extrabold tracking-[.18em] text-[#107c10]">VERIFIED LISTINGS</div><h2 className="mt-2 text-3xl font-black tracking-tight">認証済みの出品を探す</h2><p className="mt-2 text-sm text-slate-500">運営が所有確認を完了した出品のみを表示しています。</p></div><Link href="/dashboard"><Button className="bg-[#107c10] font-bold hover:bg-[#0b5f0b]"><CircleDollarSign size={17} />IDを出品する</Button></Link></div>
      <section className="mb-8 grid gap-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm md:grid-cols-[1.5fr_repeat(3,1fr)]">
        <div className="relative"><Search className="absolute left-3 top-3 text-slate-400" size={18} /><Input value={query} onChange={event => setQuery(event.target.value)} className="h-11 border-slate-200 pl-10" placeholder="IDを検索（例: Zeno）" /></div>
        <Select value={category} onValueChange={setCategory}><SelectTrigger className="h-11 border-slate-200"><SelectValue placeholder="カテゴリー" /></SelectTrigger><SelectContent><SelectItem value="all">全カテゴリー</SelectItem>{Object.entries(categoryLabels).map(([value,label]) => <SelectItem value={value} key={value}>{label}</SelectItem>)}</SelectContent></Select>
        <Select value={idLength} onValueChange={setIdLength}><SelectTrigger className="h-11 border-slate-200"><SelectValue placeholder="文字数" /></SelectTrigger><SelectContent><SelectItem value="all">文字数：すべて</SelectItem>{Array.from({ length: 15 }, (_, i) => <SelectItem value={String(i + 1)} key={i}>{i + 1}文字</SelectItem>)}</SelectContent></Select>
        <Select value={characterType} onValueChange={setCharacterType}><SelectTrigger className="h-11 border-slate-200"><SelectValue placeholder="文字種" /></SelectTrigger><SelectContent><SelectItem value="all">文字種：すべて</SelectItem><SelectItem value="alphabet">英字のみ</SelectItem><SelectItem value="alphanumeric">英数字</SelectItem><SelectItem value="mixed">数字を含む</SelectItem></SelectContent></Select>
      </section>
      <div className="mb-4 flex items-center justify-between"><p className="text-sm text-slate-500">{isLoading ? "検索中…" : `${listings?.length ?? 0} 件の認証済み出品`}</p><div className="flex items-center gap-1 text-xs font-semibold text-[#107c10]"><BadgeCheck size={15} />所有確認済みのみ</div></div>
      {isLoading ? <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{[1,2,3].map(i => <Skeleton key={i} className="h-80 rounded-2xl" />)}</div> : listings?.length ? <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{listings.map(item => <Link key={item.id} href={`/listings/${item.id}`} className="group overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm transition-all duration-200 hover:-translate-y-1 hover:shadow-lg"><div className="relative aspect-[16/9] overflow-hidden bg-slate-100"><img src={item.screenshotUrl} alt={`${item.xboxId} の所有確認画像`} className="size-full object-cover transition-transform duration-300 group-hover:scale-[1.03]" /><div className="absolute left-3 top-3"><Badge className="gap-1 border-0 bg-white/95 font-bold text-[#107c10] shadow-sm"><BadgeCheck size={14} />確認済み</Badge></div><div className="absolute bottom-3 right-3 rounded-full bg-[#0b170c]/85 px-3 py-1 text-xs font-bold text-white">{categoryLabels[item.category]}</div></div><div className="p-5"><div className="flex items-start justify-between gap-3"><div><h3 className="text-2xl font-black tracking-tight group-hover:text-[#107c10]">{item.xboxId}</h3><div className="mt-1 flex items-center gap-1 text-xs text-slate-500"><UserRoundCheck size={13} />{item.sellerHandle || "出品者"}</div></div><div className="text-right"><div className="text-xs text-slate-400">販売価格</div><div className="text-lg font-black">¥{item.priceYen.toLocaleString()}</div></div></div><p className="mt-4 line-clamp-2 text-sm leading-6 text-slate-500">{item.description}</p><div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-4 text-xs font-bold text-slate-500"><span>{new Date(item.createdAt).toLocaleDateString("ja-JP")}</span><span className="flex items-center gap-1 text-[#107c10]">詳細を見る<ChevronRight size={14} /></span></div></div></Link>)}</div> : <div className="rounded-2xl border border-dashed border-slate-300 bg-white py-16 text-center"><FileCheck2 className="mx-auto mb-3 text-slate-300" size={36}/><h3 className="font-bold">該当する出品がありません</h3><p className="mt-1 text-sm text-slate-500">検索条件を変えてお試しください。</p></div>}
    </main>
  </MarketplaceShell>;
}
