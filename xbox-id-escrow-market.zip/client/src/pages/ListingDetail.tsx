import { LoginWall, MarketplaceShell } from "@/components/MarketplaceShell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { ArrowLeft, BadgeCheck, Check, CircleDollarSign, FileCheck2, LockKeyhole, ShieldCheck, UserRoundCheck } from "lucide-react";
import { Link, useLocation, useRoute } from "wouter";
import { toast } from "sonner";

const label: Record<string, string> = { "4c": "4c", "4l": "4l", "3c": "3c", "3l": "3l", "2c": "2c", "2l": "2l", world: "world", standard: "普通のID", hive: "hive" };

export default function ListingDetail() {
  const [, params] = useRoute("/listings/:id");
  const [, navigate] = useLocation();
  const { user, isAuthenticated } = useAuth();
  const listingId = params?.id || "";
  const { data, isLoading } = trpc.marketplace.listing.useQuery({ id: listingId });
  const startDeal = trpc.deals.create.useMutation({ onSuccess: result => { toast.success("購入申込みを受け付けました。次にPayPay入金の手続きへ進みます。"); navigate(`/deals/${result.id}`); }, onError: error => toast.error(error.message) });
  if (isLoading) return <MarketplaceShell><div className="container py-10"><Skeleton className="h-7 w-36"/><div className="mt-8 grid gap-8 md:grid-cols-2"><Skeleton className="aspect-[16/10] rounded-2xl"/><Skeleton className="h-[420px] rounded-2xl"/></div></div></MarketplaceShell>;
  if (!data) return <MarketplaceShell><div className="container py-20 text-center"><FileCheck2 className="mx-auto mb-4 text-slate-300" size={40}/><h1 className="text-2xl font-black">出品が見つかりません</h1><Link href="/"><Button className="mt-6 bg-[#107c10]">出品を探す</Button></Link></div></MarketplaceShell>;
  const isOwn = user?.id === data.sellerId;
  return <MarketplaceShell><main className="container py-7 md:py-10"><Link href="/" className="inline-flex items-center gap-2 text-sm font-bold text-slate-500 hover:text-[#107c10]"><ArrowLeft size={16}/>出品一覧へ戻る</Link><div className="mt-6 grid gap-8 lg:grid-cols-[1.1fr_.9fr] lg:items-start"><section><div className="relative overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm"><img className="aspect-[16/10] w-full object-cover" src={data.screenshotUrl} alt={`${data.xboxId} の所有確認画像`} /><div className="absolute left-4 top-4"><Badge className="gap-1 border-0 bg-white/95 px-3 py-1.5 font-bold text-[#107c10]"><BadgeCheck size={15}/>運営による所有確認済み</Badge></div></div><div className="mt-5 rounded-2xl border border-[#d8ead4] bg-[#edf7eb] p-5"><div className="flex gap-3"><ShieldCheck className="mt-0.5 shrink-0 text-[#107c10]"/><div><h2 className="font-black text-[#174313]">この出品は安全な取引フローの対象です</h2><p className="mt-1 text-sm leading-6 text-slate-600">購入後、代金は運営が一時的に預かります。アカウント情報は運営が確認してから、購入者だけに引き渡されます。</p></div></div></div></section><aside className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm"><div className="flex items-center justify-between"><Badge variant="secondary" className="bg-slate-100 font-bold text-slate-700">{label[data.category]}</Badge><span className="text-xs text-slate-400">出品日 {new Date(data.createdAt).toLocaleDateString("ja-JP")}</span></div><h1 className="mt-5 text-4xl font-black tracking-tight">{data.xboxId}</h1><div className="mt-2 flex items-center gap-2 text-sm text-slate-500"><UserRoundCheck size={16}/>{data.sellerHandle || "出品者"} · {new Date(data.sellerSince).getFullYear()}年から利用</div><p className="mt-6 whitespace-pre-wrap border-y border-slate-100 py-5 text-sm leading-7 text-slate-600">{data.description}</p><div className="mt-6 flex items-end justify-between"><div><div className="text-xs font-bold text-slate-400">販売価格（税込）</div><div className="mt-1 text-3xl font-black">¥{data.priceYen.toLocaleString()}</div></div><div className="rounded-lg bg-slate-100 px-3 py-2 text-right text-xs text-slate-500"><div>運営手数料</div><div className="font-bold text-slate-700">10%</div></div></div>{!isAuthenticated ? <div className="mt-6"><LoginWall title="購入申込みにはログインが必要です" /></div> : isOwn ? <div className="mt-6 rounded-xl bg-slate-100 p-4 text-center text-sm font-bold text-slate-600">これはあなたの出品です</div> : <Button disabled={startDeal.isPending} onClick={() => startDeal.mutate({ listingId })} className="mt-6 h-12 w-full bg-[#107c10] text-base font-black hover:bg-[#0b5f0b]"><CircleDollarSign size={18}/>{startDeal.isPending ? "申込み中…" : "エスクロー取引を開始する"}</Button>}<div className="mt-5 space-y-2 text-xs text-slate-500"><div className="flex gap-2"><Check size={14} className="shrink-0 text-[#107c10]"/>購入者は運営への入金確認後に次のステップへ進みます。</div><div className="flex gap-2"><LockKeyhole size={14} className="shrink-0 text-[#107c10]"/>売り手と買い手の間で、認証情報を直接送信しません。</div></div></aside></div></main></MarketplaceShell>;
}
